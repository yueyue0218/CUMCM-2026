"""对照组：七站普查后清除；普查阶段不执行清除。"""
from src.q3.experiment_joint_routing import compact_coverage_points
from src.q3.control_scan_common import run_scan_control


def run_census_then_clear(client, **kwargs):
    return run_scan_control(client, compact_coverage_points(), clear_during_scan=False, **kwargs)
