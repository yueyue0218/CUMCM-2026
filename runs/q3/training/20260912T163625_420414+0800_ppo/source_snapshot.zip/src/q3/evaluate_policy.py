"""Paired held-out comparison of complete, planner, PPO and hybrid policies."""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if __package__ in {None, ''}:
    sys.path.insert(0, str(ROOT))

import numpy as np
import torch
from src.q3.policy_runtime import policy_configuration, rollout
from src.q3.ppo import load_policy


def evaluate(checkpoint, *, seed=40260912, cases=12, output_dir=ROOT/'results/tables'):
    if cases <= 0:
        raise ValueError('cases must be positive')
    torch.set_num_threads(1)
    policy = load_policy(checkpoint)
    config = policy_configuration(policy)
    metadata = policy.checkpoint_metadata
    train_start = metadata['seed']
    val_start = metadata['validation_seed_start']
    test_seeds = set(range(seed, seed+cases))
    if (test_seeds & set(range(train_start, train_start+metadata['episodes_completed']))
            or test_seeds & set(range(val_start, val_start+metadata['validation']['case_count']))):
        raise ValueError('evaluation seeds overlap training or model-selection seeds')
    rows = []
    for case in range(cases):
        baseline_time = None
        for mode in ('complete', 'planner', 'ppo', 'hybrid'):
            summary, _ = rollout(seed+case, mode=mode, policy=policy if mode in {'ppo','hybrid'} else None,
                                 environment_config=config)
            seconds = summary['final_virtual_time_s']
            if mode == 'complete':
                baseline_time = seconds
            row = {'seed': seed+case, 'mode': mode, 'all_cleared': summary['all_cleared'],
                   'cleared_count': summary['cleared_count'], 'total_count': summary['total_count'],
                   'virtual_time_s': seconds, 'program_runtime_s': summary['program_runtime_s'],
                   'improvement_vs_complete_pct': (baseline_time-seconds)/baseline_time*100,
                   'termination_reason': summary['termination_reason']}
            rows.append(row)
        print(json.dumps({'case': case+1, 'cases': cases, 'seed': seed+case}), flush=True)
    aggregate = {}
    for mode in ('complete','planner','ppo','hybrid'):
        selected = [r for r in rows if r['mode'] == mode]
        times = [r['virtual_time_s'] for r in selected]
        aggregate[mode] = {'success_count': sum(r['all_cleared'] for r in selected),
                           'case_count': cases, 'mean_virtual_time_s': float(np.mean(times)),
                           'worst_virtual_time_s': max(times),
                           'mean_paired_improvement_pct': float(np.mean([
                               r['improvement_vs_complete_pct'] for r in selected]))}
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    report = {'checkpoint': str(Path(checkpoint).resolve()), 'checkpoint_metadata': metadata,
              'test_seed_start': seed, 'evidence_scope': 'independent synthetic cases; not official results',
              'aggregate': aggregate, 'cases': rows}
    (output_dir/'q3_policy_comparison.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    with (output_dir/'q3_policy_comparison.csv').open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps(aggregate, indent=2), flush=True)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--seed', type=int, default=40260912)
    parser.add_argument('--cases', type=int, default=12)
    parser.add_argument('--output-dir', type=Path, default=ROOT/'results/tables')
    args = parser.parse_args()
    evaluate(args.checkpoint, seed=args.seed, cases=args.cases, output_dir=args.output_dir)
