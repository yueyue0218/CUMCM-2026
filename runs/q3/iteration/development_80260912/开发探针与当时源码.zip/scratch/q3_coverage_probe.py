import sys, math, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'scratch'))
from q3_iteration_probe import evaluate, GainController
import src.q3.experiment_joint_routing as base
from src.q3.coverage_control import covers_arena
old=base.coverage_waypoints

def cover_plan(stations, targets, current, mode='hex'):
    supplied=list(stations)+list(targets.values())
    if covers_arena(supplied):return []
    plans=[old(stations,targets,current)]
    for degrees in range(0,60,10):
        for radius in (1150,1350,1550):
            stops=[(0.,0.)]+[(radius*math.cos(math.radians(degrees+i*60)),radius*math.sin(math.radians(degrees+i*60))) for i in range(6)]
            if not covers_arena(supplied+stops):continue
            # Remove redundant stations, considering expensive insertions first.
            route=[current]+[targets[k] for k in base.optimized_route(current,targets)]
            def insertion(p):
                return min([math.dist(route[-1],p)]+[math.dist(a,p)+math.dist(p,b)-math.dist(a,b) for a,b in zip(route,route[1:])])
            for p in sorted(stops,key=insertion,reverse=True):
                rest=[x for x in stops if x!=p]
                if covers_arena(supplied+rest):stops=rest
            plans.append(stops)
    def cost(stops):
        tasks={**targets,**{21+i:p for i,p in enumerate(stops)}}
        route=[current]+[tasks[k] for k in base.optimized_route(current,tasks)]
        return sum(math.dist(a,b) for a,b in zip(route,route[1:]))+len(stops)*150
    return min(plans,key=cost)

class PlannedController(base.EfficientController):
    def run(self):
        base.coverage_waypoints=cover_plan
        try:return super().run()
        finally:base.coverage_waypoints=old

if __name__=='__main__':
    report=evaluate([('v1',base.EfficientController,{}),('cover_plan',PlannedController,{})])
    (ROOT/'scratch/q3-iteration-cover-probe.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
