import sys,json,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'scratch'))
from q3_iteration_probe import evaluate
import src.q3.experiment_joint_routing as base
from src.q3.coverage_control import covers_arena
old=base.coverage_waypoints

class ConsistentController(base.EfficientController):
    def __init__(self,*a,mode='lock',**kw):
        super().__init__(*a,**kw); self.mode=mode;self.cover_stops=None
    def planning(self,stations,targets,current):
        if self.mode=='no_future':return old(stations,{},current)
        if self.mode=='likely_future':
            return old(stations,{c:p for c,p in targets.items() if min(math.dist(p,s) for s in stations)>=1500},current)
        if self.cover_stops is None:self.cover_stops=old(stations,targets,current)
        self.cover_stops=[p for p in self.cover_stops if p not in stations]
        if not covers_arena(list(stations)+list(targets.values())+self.cover_stops):
            self.cover_stops=old(stations,targets,current)
        return self.cover_stops
    def run(self):
        base.coverage_waypoints=self.planning
        try:return super().run()
        finally:base.coverage_waypoints=old

if __name__=='__main__':
    report=evaluate([('v1',base.EfficientController,{})]+[(m,ConsistentController,{'mode':m}) for m in ('no_future','likely_future','lock')])
    (ROOT/'scratch/q3-iteration-consistency-probe.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
