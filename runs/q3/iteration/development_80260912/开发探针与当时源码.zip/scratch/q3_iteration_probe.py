"""Development-only variants; no held-out seeds and no hidden controller inputs."""
import sys, math, json, time, statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import numpy as np
from src.q3.experiment_joint_routing import EfficientController, EfficientState
from src.q3.offline_simulator import OfflineSimulator
from src.q3.training_env import sample_sources
from src.common.simulator_client import SimulatorClient

SAMPLES=np.asarray([(x,y) for x in range(-1800,1801,200) for y in range(-1800,1801,200) if x*x+y*y<=1800**2]
                   +[(1800*math.cos(i*math.pi/90),1800*math.sin(i*math.pi/90)) for i in range(180)])

class GainController(EfficientController):
    def __init__(self,*args,threshold=20,spacing=1500,**kwargs):
        super().__init__(*args,scan_spacing_m=spacing,**kwargs)
        self.threshold=threshold
    def batch(self,position,anchor=None,target_channel=None,force_scan=False):
        if self.state.unknown_channels:
            covered=np.zeros(len(SAMPLES),dtype=bool)
            for p in self.state.full_scan_stations:
                covered|=np.linalg.norm(SAMPLES-p,axis=1)<=985
            gain=np.sum((np.linalg.norm(SAMPLES-position,axis=1)<=985)&~covered)
            force_scan=force_scan or gain>=self.threshold
        super().batch(position,anchor,target_channel,force_scan)

def evaluate(variants, cases=3):
    rows=[]
    for group,n in enumerate((10,12,14,16)):
        for case in range(cases):
            seed=80260912+group*1000+case
            for name,cls,kwargs in variants:
                world=OfflineSimulator(sample_sources(seed,n),bearing_error_deg=1,error_field='spatial',quantize_bearings=True,error_phase=seed*.61803398875)
                client=SimulatorClient('iteration-dev',transport=world.transport);client.enter()
                start=time.monotonic();state=cls(client,**kwargs).run();runtime=time.monotonic()-start
                ok=state.all_cleared and world.cleared==set(world.sources)
                client.exit()
                rows.append({'name':name,'n':n,'seed':seed,'ok':ok,'seconds_per_source':client.state.virtual_time_s/n,
                             'total':client.state.virtual_time_s,'runtime':runtime,'stations':len(state.full_scan_stations)})
            print(json.dumps({'n':n,'case':case,'values':{r['name']:round(r['seconds_per_source'],2) for r in rows[-len(variants):]}}),flush=True)
    summary={name:{'mean':statistics.mean(r['seconds_per_source'] for r in rows if r['name']==name),
                   'success':sum(r['ok'] for r in rows if r['name']==name),
                   'groups':[statistics.mean(r['seconds_per_source'] for r in rows if r['name']==name and r['n']==n) for n in (10,12,14,16)]}
             for name,_,_ in variants}
    print(json.dumps(summary,indent=2),flush=True)
    return {'rows':rows,'summary':summary}

if __name__=='__main__':
    variants=[('v1',EfficientController,{})]+[(f'gain{t}',GainController,{'threshold':t}) for t in (5,15,30,60)]
    report=evaluate(variants)
    (ROOT/'scratch/q3-iteration-gain-probe.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
