import sys,math,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'scratch'))
import numpy as np
from scipy.optimize import minimize
from q3_iteration_probe import evaluate
import src.q3.experiment_joint_routing as base
from src.q3.coverage_control import covers_arena
old=base.coverage_waypoints
GRID=np.asarray([(x,y) for x in range(-1800,1801,200) for y in range(-1800,1801,200) if x*x+y*y<=1800**2]
                +[(1800*math.cos(i*math.pi/360),1800*math.sin(i*math.pi/360)) for i in range(720)])

def continuous_plan(stations,targets,current):
    initial=old(stations,targets,current)
    if not initial:return []
    supplied=list(stations)+list(targets.values())
    covered=np.zeros(len(GRID),dtype=bool)
    for p in supplied:covered|=np.linalg.norm(GRID-p,axis=1)<=985
    samples=GRID[~covered]
    if not len(samples):return initial
    tasks={**targets,**{21+i:p for i,p in enumerate(initial)}}
    order=base.optimized_route(current,tasks)
    def points(x):
        variable=x.reshape(-1,2)
        return np.asarray([current]+[tasks[k] if k<21 else variable[k-21] for k in order])
    def objective(x):return np.linalg.norm(np.diff(points(x),axis=0),axis=1).sum()/1000
    def constraint(x):return 1-np.min(np.sum((samples[:,None,:]-x.reshape(1,-1,2))**2,axis=2),axis=1)/985**2
    x0=np.asarray(initial).ravel()
    result=minimize(objective,x0,method='SLSQP',bounds=[(-1800,1800)]*len(x0),constraints={'type':'ineq','fun':constraint},options={'maxiter':30,'ftol':.002})
    candidate=[tuple(p) for p in result.x.reshape(-1,2)]
    if np.isfinite(result.x).all() and covers_arena(supplied+candidate) and objective(result.x)<objective(x0)-.001:
        for p in list(candidate):
            rest=list(candidate);rest.remove(p)
            if covers_arena(supplied+rest):candidate=rest
        return candidate
    return initial

class ContinuousController(base.EfficientController):
    def run(self):
        base.coverage_waypoints=continuous_plan
        try:return super().run()
        finally:base.coverage_waypoints=old

if __name__=='__main__':
    report=evaluate([('v1',base.EfficientController,{}),('continuous',ContinuousController,{})])
    (ROOT/'scratch/q3-iteration-continuous-probe.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
