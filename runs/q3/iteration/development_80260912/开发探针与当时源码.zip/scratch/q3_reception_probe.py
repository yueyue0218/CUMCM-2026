import sys, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'scratch'))
from q3_iteration_probe import evaluate
from q3_coverage_probe import PlannedController
from src.q3.experiment_joint_routing import EfficientController
from src.q3.reception_geometry import refine_q3_region
from src.q3.localization_control import ChannelLocalizationEvaluation, ChannelLocalizationDecision
from src.common.localization import assess_region_for_clear,LocalizationStatus

class RefinedController(EfficientController):
    def evaluation(self,c):
        key=('refined',c,len(self.state.channels[c].observations))
        if key not in self.cache:
            original=super().evaluation(c)
            if original.assessment is None:return original
            region=refine_q3_region(original.assessment.outer_region,self.state.channels[c].observations)
            assessment=assess_region_for_clear(region)
            decision={LocalizationStatus.CLEAR_READY:ChannelLocalizationDecision.READY_TO_CLEAR,
                      LocalizationStatus.COVERAGE_UNCERTAIN:ChannelLocalizationDecision.NEEDS_MORE_MEASUREMENT,
                      LocalizationStatus.MODEL_CONFLICT:ChannelLocalizationDecision.MODEL_CONFLICT}[assessment.status]
            self.cache[key]=ChannelLocalizationEvaluation(decision,assessment.clear_position if assessment.clear_ready else None,assessment)
        result=self.cache[key]
        if result.decision is ChannelLocalizationDecision.MODEL_CONFLICT:self.guard._conflict(c,'inconsistent fixed-radius evidence')
        return result

class CombinedController(RefinedController,PlannedController):pass

if __name__=='__main__':
    report=evaluate([('v1',EfficientController,{}),('reception',RefinedController,{}),('reception_cover',CombinedController,{})])
    (ROOT/'scratch/q3-iteration-reception-probe.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
