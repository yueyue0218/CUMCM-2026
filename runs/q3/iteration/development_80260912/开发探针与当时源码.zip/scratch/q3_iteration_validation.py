import sys,json,inspect,textwrap
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'scratch'))
from q3_iteration_probe import evaluate
from q3_reception_probe import RefinedController
from q3_coverage_probe import cover_plan
from src.q3.coverage_control import coverage_waypoints
from src.q3.experiment_joint_routing import EfficientController

class CandidateController(RefinedController):
    def __init__(self,*args,refine=False,pool=False,actual=False,distance=1400,angle=12,**kwargs):
        super().__init__(*args,**kwargs)
        self.refine=refine;self.plan=cover_plan if pool else coverage_waypoints
        source=textwrap.dedent(inspect.getsource(EfficientController.batch)).replace('distance<1400 and turn>=12',f'distance<{distance} and turn>={angle}')
        namespace=dict(EfficientController.batch.__globals__);exec(source,namespace);self.batch=namespace['batch'].__get__(self,type(self))
        source=textwrap.dedent(inspect.getsource(EfficientController.run)).replace('coverage_waypoints(s.full_scan_stations,tasks,self.client.state.position)','self.plan(s.full_scan_stations,tasks,self.client.state.position)')
        if actual:source=source.replace('tasks[c] = self.estimate(c)','tasks[c] = self.target(c)')
        namespace=dict(EfficientController.run.__globals__);exec(source,namespace);self.run=namespace['run'].__get__(self,type(self))
    def evaluation(self,c):
        return super().evaluation(c) if self.refine else EfficientController.evaluation(self,c)

if __name__=='__main__':
    variants=[('v1',EfficientController,{}),('r1000',CandidateController,{'distance':1000}),
              ('actual_pool',CandidateController,{'actual':True,'pool':True}),
              ('refined_actual_pool',CandidateController,{'actual':True,'pool':True,'refine':True}),
              ('r1000_actual_pool',CandidateController,{'actual':True,'pool':True,'distance':1000}),
              ('baseline150',CandidateController,{'initial_baseline_m':150}),
              ('baseline0',CandidateController,{'initial_baseline_m':0})]
    report=evaluate(variants,cases=10)
    report['variants']=[{'name':name,'kwargs':kw} for name,_,kw in variants]
    (ROOT/'scratch/q3-iteration-development40.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
