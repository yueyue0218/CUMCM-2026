import sys,json,inspect,textwrap
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'scratch'))
from q3_iteration_probe import evaluate
from src.q3.experiment_joint_routing import EfficientController

class SensingController(EfficientController):
    def __init__(self,*args,distance=1400,angle=12,**kwargs):
        super().__init__(*args,**kwargs)
        source=textwrap.dedent(inspect.getsource(EfficientController.batch)).replace('distance<1400 and turn>=12',f'distance<{distance} and turn>={angle}')
        namespace=dict(EfficientController.batch.__globals__);exec(source,namespace)
        self.batch=namespace['batch'].__get__(self,type(self))

if __name__=='__main__':
    variants=[('v1',EfficientController,{})]+[(f'r{r}_a{a}',SensingController,{'distance':r,'angle':a}) for r,a in [(500,12),(1000,12),(1400,30),(1000,30),(1400,5)]]
    report=evaluate(variants)
    (ROOT/'scratch/q3-iteration-sensing-probe.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
