import sys, math,json,inspect,textwrap
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'scratch'))
from q3_iteration_probe import evaluate
from src.q3.experiment_joint_routing import EfficientController,optimized_route
from src.q3.localization_control import ChannelLocalizationDecision

class LocalController(EfficientController):
    def __init__(self,*a,baseline='fixed',offset=100,**kw):
        super().__init__(*a,**kw);self.baseline=baseline;self.offset=offset
    def batch(self,position,anchor=None,target_channel=None,force_scan=False):
        if position==(250.,0.) and self.state.routing_steps==0 and self.baseline!='fixed':
            targets={c:self.estimate(c) for c in self.state.active_channels}
            if targets:
                first=targets[optimized_route((0.,0.),targets)[0]]
                theta=math.atan2(first[1],first[0])
                if self.baseline=='diagonal':theta+=math.pi/4
                elif self.baseline=='best':
                    angles=[math.atan2(p[1],p[0]) for p in targets.values()]
                    theta=max([theta+i*math.pi/12 for i in range(-6,7)],key=lambda a:sum(abs(math.sin(a-b)) for b in angles)+2*math.cos(a-theta))
                position=(250*math.cos(theta),250*math.sin(theta))
        super().batch(position,anchor,target_channel,force_scan)
    def target(self,c):
        e=self.evaluation(c)
        ds=[o for o in self.state.channels[c].observations if o.measure_result=='direction']
        if len(ds)==1 and e.decision is not ChannelLocalizationDecision.READY_TO_CLEAR:
            angle=math.radians(ds[0].svd_deg);center=self.estimate(c)
            return center[0]-self.offset*math.sin(angle),center[1]+self.offset*math.cos(angle)
        return super().target(c)

namespace=dict(EfficientController.run.__globals__)
exec(textwrap.dedent(inspect.getsource(EfficientController.run)).replace('tasks[c] = self.estimate(c)','tasks[c] = self.target(c)'),namespace)
class ActualTargetController(LocalController):run=namespace['run']

if __name__=='__main__':
    variants=[('v1',EfficientController,{})]+[(b,LocalController,{'baseline':b}) for b in ('toward','diagonal','best')]
    variants += [(f'offset{x}',LocalController,{'offset':x}) for x in (0,200,300)]
    variants += [('actual_targets',ActualTargetController,{})]
    report=evaluate(variants)
    (ROOT/'scratch/q3-iteration-localization-probe.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
