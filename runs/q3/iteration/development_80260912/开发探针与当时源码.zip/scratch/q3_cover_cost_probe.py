import sys,json,inspect,textwrap
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'scratch'))
from q3_iteration_probe import evaluate
import src.q3.experiment_joint_routing as base
import src.q3.coverage_control as cov
old=base.coverage_waypoints

class CoverCostController(base.EfficientController):
    def __init__(self,*a,penalty=150,boundary=1,**kw):
        super().__init__(*a,**kw)
        source=textwrap.dedent(inspect.getsource(old)).replace('(extra+150)',f'(extra+{penalty})')
        source=source.replace('for i in range(180)]',f'for i in range(180)]*{boundary}')
        namespace=dict(old.__globals__);exec(source,namespace);self.planner=namespace['coverage_waypoints']
    def run(self):
        base.coverage_waypoints=self.planner
        try:return super().run()
        finally:base.coverage_waypoints=old

if __name__=='__main__':
    variants=[('v1',base.EfficientController,{})]+[(f'cost{p}_edge{b}',CoverCostController,{'penalty':p,'boundary':b}) for p,b in [(300,1),(600,1),(1000,1),(600,3),(600,6)]]
    report=evaluate(variants)
    (ROOT/'scratch/q3-iteration-cover-cost-probe.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
