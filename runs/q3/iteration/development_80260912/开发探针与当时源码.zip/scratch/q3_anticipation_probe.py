import sys,math,json,inspect,textwrap
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'scratch'))
import numpy as np
from q3_iteration_probe import evaluate
from src.q3.experiment_joint_routing import EfficientController,optimized_route

AREA=np.asarray([(x,y) for x in range(-1750,1751,175) for y in range(-1750,1751,175) if x*x+y*y<=1800**2])

class AnticipationController(EfficientController):
    def __init__(self,*args,ghost_count=4,radius=1000,**kwargs):
        super().__init__(*args,**kwargs);self.ghost_count=ghost_count;self.radius=radius
    def choose(self,tasks):
        if not self.state.unknown_channels:return optimized_route(self.client.state.position,tasks)[0]
        possible=np.ones(len(AREA),dtype=bool)
        for p in self.state.full_scan_stations:possible&=np.linalg.norm(AREA-p,axis=1)>self.radius
        area=AREA[possible]
        if not len(area):return optimized_route(self.client.state.position,tasks)[0]
        count=min(self.ghost_count,len(area),max(1,13-len(self.state.detected_channels)))
        centers=[area[np.argmax(np.linalg.norm(area-self.client.state.position,axis=1))]]
        for _ in range(count-1):
            centers.append(area[np.argmax(np.min(np.linalg.norm(area[:,None,:]-np.asarray(centers)[None,:,:],axis=2),axis=1))])
        for _ in range(4):
            assign=np.argmin(np.linalg.norm(area[:,None,:]-np.asarray(centers)[None,:,:],axis=2),axis=1)
            centers=[area[assign==i].mean(axis=0) if np.any(assign==i) else c for i,c in enumerate(centers)]
        imagined={**tasks,**{101+i:tuple(c) for i,c in enumerate(centers)}}
        return next(c for c in optimized_route(self.client.state.position,imagined) if c in tasks)

namespace=dict(EfficientController.run.__globals__)
exec(textwrap.dedent(inspect.getsource(EfficientController.run)).replace('optimized_route(self.client.state.position,tasks)[0]','self.choose(tasks)'),namespace)
AnticipationController.run=namespace['run']

if __name__=='__main__':
    variants=[('v1',EfficientController,{})]+[(f'anticipate{k}_{r}',AnticipationController,{'ghost_count':k,'radius':r}) for k,r in [(2,1000),(4,1000),(8,1000),(4,1200)]]
    report=evaluate(variants)
    (ROOT/'scratch/q3-iteration-anticipation-probe.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
