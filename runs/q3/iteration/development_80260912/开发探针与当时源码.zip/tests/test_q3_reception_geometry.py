import math
import random
import unittest
from src.q3.baseline_scan import MeasureObservation


class ReceptionGeometryTests(unittest.TestCase):
    def test_fixed_radius_receipt_pair_excludes_the_wrong_side(self):
        from src.q3.reception_geometry import refine_q3_region
        region=[(-1500,-10),(1500,-10),(1500,10),(-1500,10)]
        obs=[MeasureObservation((0.,0.),1,'no_signal',None,0),
             MeasureObservation((1200.,0.),1,'direction',0.,1)]
        refined=refine_q3_region(region,obs)
        self.assertTrue(refined)
        self.assertGreater(min(x for x,y in refined),990)
        self.assertLessEqual(min(x for x,y in refined),1000)

    def test_disconnected_negative_disk_does_not_discard_either_possible_side(self):
        from src.q3.reception_geometry import refine_q3_region
        region=[(-1500,-10),(1500,-10),(1500,10),(-1500,10)]
        obs=[MeasureObservation((0.,0.),1,'no_signal',None,0)]
        refined=refine_q3_region(region,obs)
        self.assertLessEqual(min(x for x,y in refined),-1499)
        self.assertGreaterEqual(max(x for x,y in refined),1499)

    def test_refinement_preserves_truth_for_fixed_radius_and_bounded_errors(self):
        from src.q3.reception_geometry import refine_q3_region
        from src.common.localization import localization_region, BearingObservation
        from src.common.geometry import cross
        rng=random.Random(917)
        for _ in range(100):
            angle=rng.uniform(0,2*math.pi);r=1800*math.sqrt(rng.random())
            truth=(r*math.cos(angle),r*math.sin(angle));radius=rng.uniform(1000,1500)
            obs=[];bearings=[]
            for i in range(10):
                p=(rng.uniform(-1800,1800),rng.uniform(-1800,1800))
                if math.dist(p,truth)<=radius:
                    bearing=(math.degrees(math.atan2(truth[1]-p[1],truth[0]-p[0]))+rng.uniform(-1,1))%360
                    obs.append(MeasureObservation(p,1,'direction',bearing,i));bearings.append(BearingObservation(p,bearing))
                else:obs.append(MeasureObservation(p,1,'no_signal',None,i))
            if not bearings:continue
            refined=refine_q3_region(localization_region(bearings),obs)
            self.assertTrue(refined)
            for a,b in zip(refined,refined[1:]+refined[:1]):
                self.assertGreaterEqual(cross((b[0]-a[0],b[1]-a[1]),(truth[0]-a[0],truth[1]-a[1])),-1e-4)


if __name__=='__main__':unittest.main()
