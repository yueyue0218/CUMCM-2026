"""Q3-only conservative constraints from a source's fixed reception radius.

These implications do NOT apply to Q4 directional no_signal observations.
All clipping half-planes are relaxed outwards by an engineering guard.
"""
import math
from src.common.geometry import clip_polygon_half_plane

GUARD_M=1e-3


def _lower_clip(region, origin, axis, lower):
    point=(origin[0]+axis[0]*lower,origin[1]+axis[1]*lower)
    return clip_polygon_half_plane(region,point,(axis[1],-axis[0]))


def refine_q3_region(region, observations):
    """Return a convex outer region; never replace a disjunction with one branch.

    Received at p and absent at n imply ||g-p|| <= R < ||g-n||,
    hence (p-n).(g-(p+n)/2) > 0. Separately, absent at n implies
    ||g-n|| > 1000. In an enclosing strip |v.(g-n)| <= w<1000,
    this implies |u.(g-n)| >= sqrt(1000**2-w**2). A signed bound
    is used only if the current polygon rules out the other sign.
    """
    region=list(region)
    positives=[o.position for o in observations if o.measure_result in {'direction','near'}]
    negatives=[o.position for o in observations if o.measure_result=='no_signal']
    for n in negatives:
        for p in positives:
            distance=math.dist(p,n)
            if distance==0:
                return []  # Fixed-radius observations contradict each other.
            axis=((p[0]-n[0])/distance,(p[1]-n[1])/distance)
            midpoint=((p[0]+n[0])/2,(p[1]+n[1])/2)
            region=_lower_clip(region,midpoint,axis,-GUARD_M)
            if not region:return []
    bearing_axes=[(math.cos(math.radians(o.svd_deg)),math.sin(math.radians(o.svd_deg)))
                  for o in observations if o.measure_result=='direction']
    for _ in range(2):
        for n in negatives:
            if not region:return []
            center=(sum(p[0] for p in region)/len(region),sum(p[1] for p in region)/len(region))
            distance=math.dist(center,n)
            axes=bearing_axes[-1:]+([((center[0]-n[0])/distance,(center[1]-n[1])/distance)] if distance>GUARD_M else [])
            for u in axes:
                offsets=[(p[0]-n[0],p[1]-n[1]) for p in region]
                width=max(abs(-u[1]*x+u[0]*y) for x,y in offsets)+GUARD_M
                radius=1000.-GUARD_M
                if width>=radius:continue
                bound=math.sqrt(radius*radius-width*width)
                projection=[u[0]*x+u[1]*y for x,y in offsets]
                if min(projection)-GUARD_M > -bound:
                    region=_lower_clip(region,n,u,bound-GUARD_M)
                elif max(projection)+GUARD_M < bound:
                    region=_lower_clip(region,n,(-u[0],-u[1]),bound-GUARD_M)
                if not region:return []
    return region
